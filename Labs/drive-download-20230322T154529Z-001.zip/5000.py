import socket
from queue import PriorityQueue
import threading

ME = 5000

graph = {5000 : [(5001, 2)],
        5001 : [(5000, 2)]}
dist = {}

def dijkstra():
    pq = PriorityQueue()
    dist.clear()
    for i in range(5000, 5004):
        dist[i] = 100000
    dist[ME] = 0
    pq.put((dist[ME], ME))
    while pq.qsize():
        d, u = pq.get()
        if dist[u] != d:
            continue
        
        for (v, w) in graph[u]:
            if dist[u] + w < dist[v]:
                dist[v] = dist[u] + w
                pq.put((dist[v], v))
    
    print(f'Updated Distance Array {dist}')

def update_edge_cost(u, v, w):
    change = False
    if u not in graph.keys():
        graph[u] = []
        if (v, w) not in graph[u]:
            graph[u].append((v, w))
            change = True
    else:
        if (v, w) not in graph[u]:
            graph[u].append((v, w))
            change = True
    if v not in graph.keys():
        graph[v] = []
        if (u, w) not in graph[v]:
            graph[v].append((u, w))
            change = True
    else:
        if (u, w) not in graph[v]:
            graph[v].append((u, w))
            change = True

    if change:    
        dijkstra()

def send(sock):
    for (u, w) in graph[ME]:
        to_send = ''
        for v in graph.keys():
            for (u, w) in graph[v]:
                to_send += f'{u},{v},{w}\n'
        print(f'Sending to {u} with {to_send}')
        if u != ME:
            sock.sendto(to_send.encode(), ('127.0.0.1', int(u)))

def receive(sock):
    # try:
    data, addr = sock.recvfrom(1024)
    lst = data.decode().splitlines()
    print(lst)
    for info in lst:
        u, v, w = info.split(',')
        update_edge_cost(u, v, w)
    # except socket.timeout:
        # send(sock)
        # print(f'Timed Out')
def sent(sock):
    while True:
        send(sock)
def recvt(sock):
    while True:
        receive(sock)
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(('127.0.0.1', ME))
# sock.settimeout(5)

senThread = threading.Thread(target=send, args=(sock,))
senThread.run()

recThread = threading.Thread(target=receive, args=(sock,))
recThread.run()

# send(sock)
# cnt = 0
# while True:
#     cnt += 1
#     receive(sock)
# sock.close()